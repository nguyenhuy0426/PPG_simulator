PPG SIMULATOR - BAMBU 180 x 180 x 180 mm

In tat ca 3 file 00_ban_*_180mm.stl, moi ban MOT lan.
Tong 22 chi tiet; chi lap mot khau do moi lan.
Ban 3: 2 khau do D5 + 2 khau do D16; khong con tam bit.
Hai tam D2 van o ban 2. Mau tam bit roi co quantity=0, khong can in.
Hoac in cac file 01..13 theo quantity trong manifest.json.
GIU SCALE 100%, don vi mm. Than hop 170 x 103 x 64 mm.
Khay board 70.7 x 50.7 mm nhan board 70 x 50 mm, day danh nghia 1.6 mm.
Khe mep ban toi thieu 5 mm; khoang cach cac chi tiet toi thieu 6 mm.
Kiem tra brim/support trong slicer, khong de vuot mep ban.
Bo nay gom hop toi; khong gom de he thong va chan man hinh.
Khong dung auto-scale khi mo file, khong dung ZIP 256 mm cu.
