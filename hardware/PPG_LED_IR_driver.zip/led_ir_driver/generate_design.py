#!/usr/bin/env python3
"""Generate the wired schematic and explicitly routed KiCad 10 PCB.

Run with KiCad's pcbnew Python, then refill zones and run ERC/DRC/parity.
"""
import argparse
import csv
import json
import re
import shutil
import subprocess
import uuid
from pathlib import Path
import xml.etree.ElementTree as ET

HERE=Path(__file__).resolve().parent
NAME='led_ir_driver'
ROOT=str(uuid.uuid5(uuid.NAMESPACE_URL,'ppg-led-ir-driver-v1'))
def uid(s): return str(uuid.uuid5(uuid.UUID(ROOT),s))
def q(s): return json.dumps(str(s))
def fx(size=1.0): return f'(effects (font (size {size} {size})))'

# Pin numbers are PCB pad numbers, including module header rather than DAC IC.
PINS={
 'Conn6':[(str(i+1),n,'passive',-12.7,12.7-i*5.08,0) for i,n in enumerate(['OUT','GND','SCL','SDA','3V3','GND'])],
 'Conn2':[('1','1','passive',-10.16,2.54,0),('2','2','passive',-10.16,-2.54,0)],
 'Conn4':[(str(i+1),n,'passive',-10.16,7.62-i*5.08,0) for i,n in enumerate(['SCL','SDA','3V3','GND'])],
 'SJ3':[('1','BYP','passive',-5.08,0,0),('2','COM','passive',0,-5.08,90),('3','100R','passive',5.08,0,180)],
 'LM358P':[('1','OUT_A','output',15.24,10.16,180),('2','IN_A-','input',-15.24,5.08,0),('3','IN_A+','input',-15.24,10.16,0),('4','V-','power_in',-15.24,-10.16,0),('5','IN_B+','input',-15.24,-2.54,0),('6','IN_B-','input',-15.24,-7.62,0),('7','OUT_B','output',15.24,-2.54,180),('8','V+','power_in',15.24,-10.16,180)],
 'NPN':[('1','E','passive',0,-7.62,90),('2','B','input',-7.62,0,0),('3','C','passive',0,7.62,270)],
 'R':[('1','~','passive',0,5.08,270),('2','~','passive',0,-5.08,90)],
 'C':[('1','~','passive',0,5.08,270),('2','~','passive',0,-5.08,90)],
 'CP':[('1','+','passive',0,5.08,270),('2','-','passive',0,-5.08,90)],
 'Flag':[('1','pwr','power_out',0,0,90)],
 'Hole':[],
}
FPS={
 'Socket6':'Connector_PinSocket_2.54mm.pretty/PinSocket_1x06_P2.54mm_Vertical.kicad_mod',
 'Header2':'Connector_PinHeader_2.54mm.pretty/PinHeader_1x02_P2.54mm_Vertical.kicad_mod',
 'Header4':'Connector_PinHeader_2.00mm.pretty/PinHeader_1x04_P2.00mm_Vertical.kicad_mod',
 'SJ3':'Jumper.pretty/SolderJumper-3_P2.0mm_Open_TrianglePad1.0x1.5mm.kicad_mod',
 'DIP8':'Package_DIP.pretty/DIP-8_W7.62mm_Socket.kicad_mod',
 'NPN':'Package_TO_SOT_THT.pretty/TO-92_Inline_Wide.kicad_mod',
 'R':'Resistor_SMD.pretty/R_0805_2012Metric_Pad1.20x1.40mm_HandSolder.kicad_mod',
 'RSense':'Resistor_SMD.pretty/R_1206_3216Metric_Pad1.30x1.75mm_HandSolder.kicad_mod',
 'C':'Capacitor_SMD.pretty/C_0805_2012Metric_Pad1.18x1.45mm_HandSolder.kicad_mod',
 'CP':'Capacitor_SMD.pretty/CP_Elec_5x5.4.kicad_mod',
 'Hole':'MountingHole.pretty/MountingHole_3.2mm_M3.kicad_mod',
}
PARTS=[]
# anchor=False: v2.0 parts placed directly on the compact board; they have no
# legacy 7.62 mm THT routing anchor for route_board to fan out from.
def part(ref,kind,value,nets,fp,xy,sch,angle=0,dnp=False,anchor=True):
    PARTS.append(dict(ref=ref,kind=kind,value=value,nets=nets,fp=fp,xy=xy,sch=sch,angle=angle,dnp=dnp,anchor=anchor))

for ch,s,x in [('IR','J1',7),('RED','J3',40)]:
    # v2.0: each module has its own I2C header. Socket pin 6 is the module's
    # I2C ground (same VSS as pin 2 inside the module), not the board GND net.
    ns=[f'DAC_{ch}','GND',f'SCL_{ch}',f'SDA_{ch}',f'3V3_{ch}',f'GNDI2C_{ch}']
    part(s,'Conn6',f'MCP4725 {ch} '+('0x60' if ch=='IR' else '0x61'),ns,'Socket6',(x,10),(43.18 if ch=='IR' else 228.6,50.8))
part('J2','Conn2','IR DAC OUT / GND',['DAC_IR','GND'],'Header2',(29,10),(116.84,50.8))
# Per-channel I2C input: header -> 100R or bypass (3-pad solder jumper) -> module.
# Jumpers ship open; the module sees no SCL/SDA until one side is bridged.
# Each R/JP pair sits between its 2.00 mm header and its module socket (under
# the plugged module body). xy is the compact-board position plus the 5 mm
# offset removed after routing.
for ch,j,x,dx,refs in [('IR','J8',29,0,(11,12,1,2)),('RED','J9',68.3,33,(13,14,3,4))]:
    part(j,'Conn4',f'I2C {ch}: SCL SDA 3V3 GND',[f'SCL_H_{ch}',f'SDA_H_{ch}',f'3V3_{ch}',f'GNDI2C_{ch}'],'Header4',(x,16.5),(0,0),anchor=False)
    for sig,r,jp,cx in [('SCL',refs[0],refs[2],13+dx),('SDA',refs[1],refs[3],21+dx)]:
        part(f'R{r}','R','100R 1%',[f'{sig}_H_{ch}',f'{sig}_R_{ch}'],'R',(cx,9.6),(0,0),anchor=False)
        part(f'JP{jp}','SJ3',f'{sig} {ch} 1-2 BYP / 2-3 100R',[f'{sig}_H_{ch}',f'{sig}_{ch}',f'{sig}_R_{ch}'],'SJ3',(cx,12.6),(0,0),anchor=False)

part('J4','Conn2','RED DAC OUT / GND',['DAC_RED','GND'],'Header2',(62,10),(330.2,40.64))

part('U1','LM358P','LM358P / DIP8 socket',['AMP_IR','SENSE_IR','CMD_IR','GND','CMD_RED','SENSE_RED','AMP_RED','5V'],'DIP8',(31.19,30.19),(193.04,139.7))
for i,ch in enumerate(['IR','RED']):
    sx=38.1+i*190.5
    left=i==0
    part(f'Q{i+1}','NPN','2N4401 / E-B-C',[f'SENSE_{ch}',f'BASE_{ch}',f'LED_K_{ch}'],'NPN',(18 if left else 47,41),(sx+66.04,152.4))
    for ref,val,ns,xy,sc,ang,dnp in [
      (f'R{1+i*5}','10k 1%',[f'DAC_{ch}',f'CMD_{ch}'],(9 if left else 46,27),(sx,114.3),0,False),
      (f'R{2+i*5}','10k 1%',[f'CMD_{ch}','GND'],(16.62 if left else 53.62,31),(sx,147.32),180,False),
      (f'R{3+i*5}','1k',[f'AMP_{ch}',f'BASE_{ch}'],(23 if left else 46,29.5 if left else 35),(sx+33.02,114.3),270 if left else 0,False),
      (f'R{4+i*5}','100R 1% 0.25W',[f'SENSE_{ch}','GND'],(12 if left else 48,46),(sx+66.04,187.96),0,False),
    ]: part(ref,'R',val,ns,'RSense' if ref in ('R4','R9') else 'R',xy,sc,ang,dnp)
    part(f'C{2+i*2}','C','DNP loop comp',[f'AMP_{ch}',f'SENSE_{ch}'],'C',(27 if left else 43,38),(sx+99.06,187.96),270,True)
    part(f'J{5+i}','Conn2',f'{ch} LED A / K',['5V',f'LED_K_{ch}'],'Header2',(23 if left else 46,50),(sx+99.06,114.3),90)
part('J7','Conn2','5V INPUT / GND',['5V','GND'],'Header2',(34,50),(193.04,218.44),90)
part('C5','C','100nF X7R 50V',['5V','GND'],'C',(38.81,26),(132.08,226.06))
part('C7','CP','10uF 16V',['5V','GND'],'CP',(30,45),(292.1,226.06))
for i,xy in enumerate([(4,4),(66,4),(4,51),(66,51)],1):
    part(f'H{i}','Hole','M3 / 3.2mm',[],'Hole',xy,(30.48+i*22.86,264.16))

def symbol(kind):
    ref={'R':'R','C':'C','CP':'C','NPN':'Q','LM358P':'U','Flag':'#FLG','Hole':'H','SJ3':'JP'}.get(kind,'J')
    names='(pin_names (offset 0.5) (hide yes))' if kind=='SJ3' else '(pin_names (offset 0.5))'
    out=[f'(symbol "TX:{kind}" {names} (in_bom yes) (on_board yes)',f'(property "Reference" "{ref}" (at 0 18 0) {fx()})',f'(property "Value" "{kind}" (at 0 16 0) {fx()})',f'(symbol "{kind}_0_1"']
    if kind in ('Conn6','Conn2','Conn4','LM358P'):
        w,h={'Conn2':(5.08,5.08),'Conn4':(5.08,10.16)}.get(kind,(10.16,15.24))
        out.append(f'(rectangle (start {-w} {h}) (end {w} {-h}) (stroke (width 0.254) (type default)) (fill (type background)))')
    elif kind=='R':
        out.append('(rectangle (start -1.27 3.81) (end 1.27 -3.81) (stroke (width 0.254) (type default)) (fill (type none)))')
    elif kind=='SJ3':
        # Three pads with two open gaps; COM is the middle pad.
        for x0 in (-2.54,-.635,1.27):
            out.append(f'(rectangle (start {x0} 1.27) (end {x0+1.27} -1.27) (stroke (width 0.254) (type default)) (fill (type none)))')
        out.append('(polyline (pts (xy 0 -1.27) (xy 0 -2.54)) (stroke (width 0.254) (type default)) (fill (type none)))')
    elif kind in ('C','CP'):
        for yy in (-.762,.762): out.append(f'(polyline (pts (xy -2.54 {yy}) (xy 2.54 {yy})) (stroke (width 0.254) (type default)) (fill (type none)))')
        if kind=='CP': out.append(f'(text "+" (at -3.5 2.5 0) {fx()})')
    elif kind=='NPN':
        for points in ['-2.54 -3.81) (xy -2.54 3.81','-2.54 1.27) (xy 0 5.08','-2.54 -1.27) (xy 0 -5.08','-7.62 0) (xy -2.54 0','-1.8 -4.4) (xy 0 -5.08) (xy -.1 -3.1']:
            out.append(f'(polyline (pts (xy {points})) (stroke (width .254) (type default)) (fill (type none)))')
    else: out.append('(circle (center 0 0) (radius 1.27) (stroke (width .254) (type default)) (fill (type none)))')
    out+=[')',f'(symbol "{kind}_1_1"']
    for num,name,typ,x,y,ang in PINS[kind]:
        length=0 if kind=='Flag' else (1.27 if kind=='R' else (4.318 if kind in ('C','CP') else (2.54 if kind in ('NPN','SJ3') else 5.08)))
        out.append(f'(pin {typ} line (at {x} {y} {ang}) (length {length}) (name {q(name)} {fx()}) (number "{num}" {fx()}))')
    return '\n'.join(out+['))'])

def board(share,cli):
    import pcbnew as p
    mm=p.FromMM
    def vec(x,y): return p.VECTOR2I(mm(x),mm(y))
    b=p.BOARD(); b.GetDesignSettings().SetCopperLayerCount(2)
    b.GetDesignSettings().SetBoardThickness(mm(1.6))
    subprocess.run([cli,'sch','export','netlist','--format','kicadxml','-o',str(HERE/'reports'/f'{NAME}.net'),str(HERE/f'{NAME}.kicad_sch')],check=True)
    pin_nets={}
    for n in ET.parse(HERE/'reports'/f'{NAME}.net').findall('.//nets/net'):
        net=p.NETINFO_ITEM(b,n.attrib['name']); b.Add(net)
        for nd in n.findall('node'): pin_nets[nd.attrib['ref'],nd.attrib['pin']]=net
    lib=HERE/'TX.pretty'; lib.mkdir(exist_ok=True)
    for name,src in FPS.items():
        s=(share/'footprints'/src).read_text()
        s=re.sub(r'^\(footprint "[^"]+"',f'(footprint "{name}"',s)
        for model in re.findall(r'\(model "([^\"]+)"',s):
            suffix=model.split('}/')[-1]; source=share/'3dmodels'/suffix
            if source.exists():
                dest=HERE/'3dmodels'/suffix; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(source,dest)
                s=s.replace(model,'${KIPRJMOD}/3dmodels/'+suffix)
        (lib/f'{name}.kicad_mod').write_text(s)
    (lib/'HeaderMixed.kicad_mod').unlink(missing_ok=True)
    (HERE/'fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "TX") (type "KiCad") (uri "${KIPRJMOD}/TX.pretty") (options "") (descr "Driver local footprints")))')
    footprints={}
    for d in PARTS:
        fp=p.FootprintLoad(str(lib),d['fp']); fp.SetReference(d['ref']); fp.SetValue(d['value']); fp.SetFPID(p.LIB_ID('TX',d['fp']))
        x,y=d['xy']; fp.SetPosition(vec(100+x,100+y)); fp.SetOrientationDegrees(d['angle'])
        # SMD packages are centred between the original routing anchors.
        # Preserve those anchors for short straight fanouts in route_board.
        if d['kind'] in ('R','C','CP') and d['anchor']:
            import math
            half={'R':3.81,'C':1.25,'CP':1.0}[d['kind']]
            a=math.radians(d['angle'])
            fp.SetPosition(vec(100+x+half*math.cos(a),100+y-half*math.sin(a)))
        path=p.KIID_PATH(); path.push_back(p.KIID(ROOT)); path.push_back(p.KIID(uid(d['ref']))); fp.SetPath(path)
        fp.SetAttributes(fp.GetAttributes() & ~p.FP_EXCLUDE_FROM_BOM)
        if d['dnp']: fp.SetAttributes(fp.GetAttributes() | p.FP_DNP)
        for pad in fp.Pads():
            if (d['ref'],pad.GetNumber()) in pin_nets: pad.SetNet(pin_nets[d['ref'],pad.GetNumber()])
        fp.Value().SetVisible(False)
        fp.Reference().SetTextSize(vec(.8,.8)); fp.Reference().SetTextThickness(mm(.12)); fp.Reference().SetTextAngle(p.EDA_ANGLE(0,p.DEGREES_T))
        fp.Reference().SetPosition(vec(100+x+2,100+y-2.5))
        if d['kind']=='Hole': fp.Reference().SetVisible(False)
        b.Add(fp); footprints[d['ref']]=fp
    def line(a,c,layer):
        s=p.PCB_SHAPE(); s.SetShape(p.SHAPE_T_SEGMENT); s.SetStart(vec(100+a[0],100+a[1])); s.SetEnd(vec(100+c[0],100+c[1])); s.SetLayer(layer); s.SetWidth(mm(.05 if layer==p.Edge_Cuts else .15)); b.Add(s)
    for a,c in [((0,0),(70,0)),((70,0),(70,55)),((70,55),(0,55)),((0,55),(0,0))]: line(a,c,p.Edge_Cuts)
    def silk(s,x,y,size=1,back=False,angle=0):
        t=p.PCB_TEXT(b); t.SetText(s); t.SetPosition(vec(100+x,100+y)); t.SetTextSize(vec(size,size)); t.SetTextThickness(mm(.13)); t.SetLayer(p.B_SilkS if back else p.F_SilkS); t.SetMirrored(back); t.SetTextAngle(p.EDA_ANGLE(angle,p.DEGREES_T)); b.Add(t)
    silk('DATN: PPG-Simulator',35,2.8,1,True)
    silk('Nguyen Nhat Huy - Pham Thanh Vy',35,6,.8,True)
    silk('PPG TX  v1.6',35,2.5)
    for x,ch,addr in [(7,'IR','0x60'),(40,'RED','0x61')]:
        silk('MCP4725 '+ch+' '+addr,x+9,4.6,.85)
        silk('ADDR='+('GND' if ch=='IR' else 'VCC'),x+9,6.3,.8)
        for i,label in enumerate(['OUT','GND','SCL','SDA','3V3','GND']): silk(label,x+5.5,10+i*2.54,.8)
        # Module body projection is an assembly guide, not a measured outline.
        for a,c in [((x+1,6),(x+19,6)),((x+19,6),(x+19,23)),((x+19,23),(x+1,23))]: line(a,c,p.Dwgs_User)
    silk('RED OUT',62,7.5,.8)
    silk('OUT',66,10,.8); silk('GND',66,12.54,.8)
    silk('J4 RED OUT',62,7.5,.8,True)
    silk('OUT',66,10,.8,True); silk('GND',66,12.54,.8,True)
    silk('IR A+ K-',24,53.5,.8); silk('RED A+ K-',47,53.5,.8); silk('5V GND',35,53.5,.8)
    silk('DAC: 3.3V ONLY',35,6.5,.9)
    for i,label in enumerate(['OUT','GND']):
        silk(label,32,(10,12.54)[i],.8)
    silk('C2 / C4: DNP',35,41.5,.8)
    silk('100R',15.8,48.2,.8); silk('100R',51.8,48.2,.8)
    for x in (18,47):
        for i,s in enumerate(('E','B','C')): silk(s,x+2.54*i,44,.8)

    def pad_local(ref,pin):
        pad=next(x for x in footprints[ref].Pads() if x.GetNumber()==str(pin)); pos=pad.GetPosition(); return p.ToMM(pos.x)-100,p.ToMM(pos.y)-100
    # Rear labels use signal names only; connector/component references remain.
    for ref,title,labels,label_x in (
        ('J1','J1 IR DAC',('IR_OUT','GND','SCL','SDA','3V3','I2CGND'),12),
        ('J2','J2 IR OUT',('IR_OUT','GND'),34),
        ('J3','J3 RED DAC',('RED_OUT','GND','SCL','SDA','3V3','I2CGND'),45),
    ):
        x0,_=pad_local(ref,1); silk(title,x0,7.8,.8,True)
        for pin,label in enumerate(labels,1):
            _,y=pad_local(ref,pin); silk(label,label_x,y,.8,True)
    for ref,title,labels in (
        ('J5','J5 IR LED',('A+','K-')),
        ('J6','J6 RED LED',('A+','K-')),
        ('J7','J7 POWER',('5V','GND')),
    ):
        coords=[pad_local(ref,pin) for pin in (1,2)]
        silk(title,sum(x for x,_ in coords)/2,48.2,.8,True)
        for (x,_),label in zip(coords,labels): silk(label,x,53.0,.8,True)
    silk('U1 LM358',35,27.2,.8,True)
    for pin,label in ((1,'AMP_I'),(2,'SNS_I'),(3,'CMD_I'),(4,'GND')):
        _,y=pad_local('U1',pin); silk(label,5.0,y,.8,True)
    for pin,label in ((8,'5V'),(7,'AMP_R'),(6,'SNS_R'),(5,'CMD_R')):
        _,y=pad_local('U1',pin); silk(label,65.0,y,.8,True)
    for ref,title in (('Q1','Q1 IR E-B-C'),('Q2','Q2 RED E-B-C')):
        coords=[pad_local(ref,pin) for pin in (1,2,3)]
        silk(title,sum(x for x,_ in coords)/3,39.2,.8,True)
        for (x,_),label in zip(coords,('E','B','C')): silk(label,x,43.7,.8,True)
    # Place refdes in nearby free silk area without crossing component outlines.
    def rect(bb,pad=.15):
        return (p.ToMM(bb.GetX())-pad,p.ToMM(bb.GetY())-pad,p.ToMM(bb.GetRight())+pad,p.ToMM(bb.GetBottom())+pad)
    def overlap(a,c): return a[0]<c[2] and a[2]>c[0] and a[1]<c[3] and a[3]>c[1]
    occupied=[rect(t.GetBoundingBox()) for t in b.GetDrawings() if t.GetLayer()==p.F_SilkS]
    for fp in b.GetFootprints():
        for item in list(fp.GraphicalItems())+list(fp.Pads()):
            if isinstance(item,p.PAD) or item.GetLayer() in (p.F_SilkS,p.F_CrtYd): occupied.append(rect(item.GetBoundingBox()))
    for fp in sorted(b.GetFootprints(),key=lambda f:f.GetReference()):
        if fp.GetReference().startswith('H'): continue
        t=fp.Reference(); pos=fp.GetPosition(); x,y=p.ToMM(pos.x),p.ToMM(pos.y)
        candidates=[(dx*dx+dy*dy,dx,dy) for dx in range(-9,11) for dy in range(-7,8)]
        for _,dx,dy in sorted(candidates):
            t.SetPosition(vec(x+dx,y+dy)); r=rect(t.GetBoundingBox())
            if r[0]>100.5 and r[2]<169.5 and r[1]>100.5 and r[3]<154.5 and not any(overlap(r,c) for c in occupied):
                occupied.append(r); break
        else: raise RuntimeError('No refdes position for '+fp.GetReference())
    from route_board import route_board
    route_board(b, PARTS)
    # Compact v1.8: preserve all copper routing relationships, translate the
    # populated region upward, and relocate the two upper mounting holes.
    for item in list(b.GetFootprints())+list(b.GetTracks())+list(b.GetDrawings())+list(b.Zones()):
        item.Move(vec(0,-5))
    for item in list(b.GetDrawings()):
        if item.GetLayer()==p.Edge_Cuts: b.Remove(item)
    for a,c in [((0,0),(70,0)),((70,0),(70,48)),((70,48),(0,48)),((0,48),(0,0))]: line(a,c,p.Edge_Cuts)
    for i,(x,y) in enumerate(((4,25),(66,25),(4,44),(66,44)),1):
        footprints[f'H{i}'].SetPosition(vec(100+x,100+y))
        next(iter(footprints[f'H{i}'].Pads())).SetLocalClearance(mm(.8))
    for z in b.Zones():
        z.Outline().RemoveAllContours(); poly=z.Outline(); poly.NewOutline()
        for x,y in ((100.6,100.6),(169.4,100.6),(169.4,147.4),(100.6,147.4)): poly.Append(vec(x,y).x,vec(x,y).y)
    for t in b.GetDrawings():
        if not isinstance(t,p.PCB_TEXT): continue
        txt=t.GetText()
        if txt=='PPG TX  v1.6': t.SetText('PPG TX v1.8'); t.SetPosition(vec(135,100.9)); t.SetTextSize(vec(.8,.8))
        if txt=='DAC: 3.3V ONLY': b.Remove(t); continue; t.SetTextSize(vec(.8,.8))
        if txt.startswith('MCP4725'): t.SetPosition(vec(p.ToMM(t.GetPosition().x),101.0))
        if txt.startswith('ADDR='): t.SetPosition(vec(p.ToMM(t.GetPosition().x),102.8))
        if txt=='DATN: PPG-Simulator': t.SetPosition(vec(135,100.9))
        if txt=='Nguyen Nhat Huy - Pham Thanh Vy': t.SetPosition(vec(135,119.4)); t.SetTextSize(vec(.8,.8))
        if t.GetLayer()==p.B_SilkS and txt=='AMP_I': t.SetPosition(vec(109,123.9))
        if t.GetLayer()==p.B_SilkS and txt=='5V' and p.ToMM(t.GetPosition().x)>160: t.SetPosition(vec(161,125.19))
    for t in b.GetDrawings():
        if not isinstance(t,p.PCB_TEXT): continue
        if t.GetText() in ('IR A+ K-','RED A+ K-','5V GND'):
            b.Remove(t); continue
        elif p.ToMM(t.GetPosition().y)>147.0:
            t.SetPosition(vec(p.ToMM(t.GetPosition().x),146.5))
    p.ZONE_FILLER(b).Fill(b.Zones())
    p.SaveBoard(str(HERE/f'{NAME}.kicad_pcb'),b)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--share',required=True,type=Path); ap.add_argument('--cli',required=True); a=ap.parse_args()
    (HERE/'reports').mkdir(exist_ok=True)
    project={'meta':{'filename':NAME+'.kicad_pro','version':1},'board':{'design_settings':{'rules':{'min_clearance':.25,'min_track_width':.3,'min_through_hole_diameter':.3,'min_hole_clearance':.25,'min_copper_edge_clearance':.3}}},'net_settings':{'classes':[{'name':'Default','clearance':.25,'track_width':.35,'via_diameter':.8,'via_drill':.4,'microvia_diameter':.3,'microvia_drill':.1,'diff_pair_width':.2,'diff_pair_gap':.25,'diff_pair_via_gap':.25}]}}
    (HERE/f'{NAME}.kicad_pro').write_text(json.dumps(project,indent=2)+'\n')
    from schematic_connected import write_schematic
    write_schematic(HERE,NAME,ROOT,PARTS,uid,q,fx,symbol)
    board(a.share,a.cli)
    from compact_layout import compact
    compact()
    with (HERE/'BOM.csv').open('w') as f:
        w=csv.writer(f,lineterminator="\n"); w.writerow(['Reference','Value','Footprint','Fit'])
        for d in PARTS: w.writerow([d['ref'],d['value'],'TX:'+d['fp'],'DNP' if d['dnp'] else ('BRIDGE' if d['kind']=='SJ3' else 'YES')])

if __name__=='__main__': main()
