BOARD: led_ir_driver
SIZE: 70 x 55 mm, 2 copper layers, FR-4 1.6 mm

For fabrication use the files in fabrication/: Gerber layers plus PTH and NPTH Excellon drill files. The .kicad_pcb, .kicad_sch and .kicad_pro files provide the editable KiCad 10 project. Footprints, symbols and 3D models are included for opening the project. See README.md and the ERC/DRC reports for assembly and verification details.

PCB SHA256: 6c00fdfae48882f1c9ec16acbceb490b255f5bd629ec135dfa0399f2e1ba63d9
