# PPG: manufacture ONE 70 x 110 mm V-score panel

Manufacturing input: **hardware/ppg_panel/fabrication/** only.
Read **hardware/ppg_panel/reports/vcut_drawing.pdf** and **hardware/ppg_panel/README.md**.
2 copper layers, FR-4 1.6 mm, 1 oz, mask and white silkscreen on both sides.
Three DIFFERENT designs, one copy each: OPT101 70x30, BPW34 70x30, LED/IR 70x50 mm.
Two full-width V-score lines at Y=30/60 mm from the top edge; score both sides.
The User_Comments Gerber is a V-score guide, NOT copper and NOT a milling slot.
Edge_Cuts is only the outer rectangle. Copper clearance to score centre >=0.60 mm each side.
Factory to confirm score depth/tolerances and price for a three-design panel.
Depanel before assembly. Source projects and mechanical STLs are reference material, not extra PCB quantities.

Gói này chỉ có một bộ Gerber sản xuất: panel trong hardware/ppg_panel/fabrication/.
Không sản xuất thêm các PCB lẻ từ thư mục source. File *_print.stl là gá in 3D, không thuộc gia công PCB.
Schematic/BOM, báo cáo kiểm tra và giới hạn thử nghiệm nằm trong các project và ELECTRICAL_REVIEW.md.
Thiết kế đã kiểm tra CAD; chưa đo kiểm analog trên PCB thực.
