BOARD: opt101_receiver
SIZE: 70 x 32 mm, 2 copper layers, FR-4 1.6 mm

For fabrication use the files in fabrication/: Gerber layers plus PTH and NPTH Excellon drill files. The .kicad_pcb, .kicad_sch and .kicad_pro files provide the editable KiCad 10 project. Footprints, symbols and 3D models are included for opening the project. See README.md and the ERC/DRC reports for assembly and verification details.

PCB SHA256: b55a0d920a80af6baae54df9d9ab7d2e63e093b5d7d778a09bbc501e494fd382
