BOARD: bpw34_receiver
SIZE: 70 x 32 mm, 2 copper layers, FR-4 1.6 mm

For fabrication use the files in fabrication/: Gerber layers plus PTH and NPTH Excellon drill files. The .kicad_pcb, .kicad_sch and .kicad_pro files provide the editable KiCad 10 project. Footprints, symbols and 3D models are included for opening the project. See README.md and the ERC/DRC reports for assembly and verification details.

PCB SHA256: fdd18089250e073b17137979da79e90a486de3fc4a6c390fdb173d25208dd11e
