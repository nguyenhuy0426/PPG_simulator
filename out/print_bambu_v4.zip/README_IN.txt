PPG SIMULATOR - CO KHI V4 (2026-09-06)

Don vi mm, scale 100%.
In 00_ban_1_co_khi.stl va 00_ban_2_khau_do_khung.stl, moi ban 1 lan.
Tong 23 chi tiet, du 2 lan Do/IR. Moi lan chi lap 1 khau do.
Hoac in tung file 01..13 theo quantity trong manifest.json; khong in them ban gop.
Truc day tron: 12_truc_day_tron_D5x130.stl, can 2 ban.
Vit chan carrier: 2 x M3x8; vit chan num: 2 x M3x6.
Carrier nhan truc sau 15 mm, num nhan truc sau 6 mm.
Kiem tra support/brim trong slicer (nhat la truc tron, be truc va chup).
CAD da kiem tra giao nhau. Chua do co ngot, do tro, luc truot, ro sang tren ban in.
Xem fit_review.png, fit_report.json va huong dan chi tiet trong ma nguon:
docs/system_3d/README.md.
